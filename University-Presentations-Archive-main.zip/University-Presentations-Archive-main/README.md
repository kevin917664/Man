# University-Presentations-Archive
This repository contains all my university presentations on data science, AI, machine learning, finance, project mangaement and business strategy. These presentations reflect my academic journey, problem-solving approach, and insights into real-world applications.
